-- 1025Dex Crazy Randomizer v0.4.23
-- Runtime-form architecture:
--   * uses the OFFICIAL 1025Dex 1.2.13 as-is;
--   * registers non-Gigantamax alternate forms from a bundled form-data
--     snapshot directly from Crazy Randomizer, in memory;
--   * Mega forms are included.  Empty Mega learnsets inherit their base
--     species' level progression before randomization;
--   * randomizes the COMPLETE level-up learnset, not just the first four;
--   * keeps the battle layer executable by using real Gen3 move IDs (1..354).
--     1025Dex's Gen3 compatibility data is represented by this executable
--     native move pool; modern moves that have no Gen3 implementation cannot
--     be made executable merely by naming them.
--   * trainer species and trainer move sets are randomized from the same pool.

local MOD_VERSION = "0.4.23"
local SPECIES_COUNT = 1025
local FORM_SLOT_START = 1090
local LCG_MOD = 2147483647
local MOD_TAG = "__1025dexCrazyRandomizer_v0423"

return function(mod)
  mod.options:define({
    { key = "enabled", label = "Enable wild randomization", type = "toggle", default = true },
    { key = "seed", label = "Randomizer seed", type = "number", default = 20261006, min = 1, max = 2147483646, step = 1 },
    { key = "scope", label = "Randomization pool", type = "choice", default = "all", choices = {
      { "ALL 1025 + FORMS", "all" },
      { "1025DEX ACTIVE POOL", "active" },
    }},
    { key = "exclude_gmax", label = "Exclude Gigantamax", type = "toggle", default = true },
    { key = "randomize_moves", label = "Randomize complete Pokémon learnsets", type = "toggle", default = true },
    { key = "type_affinity", label = "Type affinity", type = "toggle", default = true },
    { key = "randomize_trainers", label = "Randomize trainer Pokémon", type = "toggle", default = true },
    { key = "level_cap_enabled", label = "Dynamic Gym/Champion Level Cap", type = "toggle", default = true },
    { key = "trainer_allow_megas", label = "Allow Megas in trainers", type = "toggle", default = true },
    { key = "trainer_party_mode", label = "Trainer party size", type = "choice", default = "important6", choices = {
      { "VANILLA: ORIGINAL PARTY SIZES", "vanilla" },
      { "MEDIUM: IMPORTANT 6 / COMMON MIXED (20% SIX)", "important6" },
      { "FULL POKEMON: ALL TRAINERS 6", "full6" },
    }},
    { key = "trainer_extended_anim_safety", label = "Trainer enemy animation safety", type = "toggle", default = true },
    { key = "trainer_skip_enemy_anim", label = "Skip trainer enemy intro animation (Emerald safety)", type = "toggle", default = true },
    { key = "trainer_optional_double_cap", label = "Max Pokémon per OPTIONAL double-battle trainer", type = "number", default = 3, min = 2, max = 3, step = 1 },
    { key = "reroll_seed", label = "Generate new random seed", type = "choice", default = "idle", choices = {
      { "NO", "idle" },
      { "GENERATE NEW SEED", "generate" },
    }},
    { key = "untamed_compat", label = "Untamed Advanced compatibility", type = "toggle", default = true },
  })

  if not mod.options:get("enabled") then
    mod.log:info("Crazy Randomizer %s disabled", MOD_VERSION)
    return
  end

  local dex = mod:find("1025dex")
  local untamed = mod:find("untamed_advanced")
  if not dex or not dex.exports then
    mod.log:error("Required dependency 1025Dex is unavailable; Crazy Randomizer cannot start")
    return
  end
  if untamed then
    mod.log:info("Crazy Randomizer: Untamed Advanced detected; compatibility bridge enabled")
  else
    mod.log:info("Crazy Randomizer: Untamed Advanced not installed; continuing without Untamed integration")
  end

  local originalDexNav = dex.exports.dexnavEncounters
  local originalChoose = dex.exports.chooseWildEncounter
  if type(originalDexNav) ~= "function" or type(originalChoose) ~= "function" then
    mod.log:error("1025Dex live encounter exports unavailable; Crazy Randomizer cannot start")
    return
  end

  -- A seed belongs to the active save, not to the installation-wide options.
  -- mod.save is scoped by Gen1Recomp to the active playthrough.
  -- Keep the active seed in memory as well as in the save adapter. Some engine
  -- transitions expose the newly-created SaveData object before mod.save's
  -- adapter has refreshed; relying on a read-back alone can leave builders on
  -- the installation fallback seed.
  local activeSeedOverride = nil
  local function activeSeed()
    if activeSeedOverride and activeSeedOverride >= 1 and activeSeedOverride < LCG_MOD then
      return math.floor(activeSeedOverride)
    end
    local saved = mod.save and mod.save.get and tonumber(mod.save:get("crazy_seed")) or nil
    if saved and saved >= 1 and saved < LCG_MOD then return math.floor(saved) end
    return tonumber(mod.options:get("seed")) or 20261006
  end

  local seedGenerationSerial = 0
  local lastGeneratedSeed = nil
  local function makeFreshSeed(existing)
    local base = tonumber(mod.options:get("seed")) or 20261006
    local now = os.time() or 0
    local clock = 0
    if love and love.timer and love.timer.getTime then clock = math.floor(love.timer.getTime() * 1000000) end
    seedGenerationSerial = seedGenerationSerial + 1
    local previous = tonumber(existing) or tonumber(lastGeneratedSeed) or activeSeed()
    -- Mix the previous seed and serial in, so repeated New Game operations in
    -- the same second cannot repeat merely because the wall clock is unchanged.
    local entropy = (clock + seedGenerationSerial * 104729 + previous * 8191) % (LCG_MOD - 1)
    local seed = math.floor((base * 48271 + now * 1103515245 + entropy) % (LCG_MOD - 1)) + 1
    if seed == previous then seed = (seed % (LCG_MOD - 1)) + 1 end
    if lastGeneratedSeed and seed == lastGeneratedSeed then seed = (seed % (LCG_MOD - 1)) + 1 end
    lastGeneratedSeed = seed
    return seed
  end

  local function persistFreshPlaythroughSeed(forceNew)
    local existing = mod.save and mod.save.get and tonumber(mod.save:get("crazy_seed")) or nil
    if not forceNew and existing and existing >= 1 and existing < LCG_MOD then
      activeSeedOverride = math.floor(existing)
      mod.log:info("Crazy Randomizer: restored per-playthrough seed %d", activeSeedOverride)
      return activeSeedOverride
    end
    local seed = makeFreshSeed(existing)
    activeSeedOverride = seed
    if mod.save and mod.save.set then mod.save:set("crazy_seed", seed) end
    mod.log:info("Crazy Randomizer: %s per-playthrough seed %d (serial=%d)", forceNew and "generated" or "initialized", seed, seedGenerationSerial)
    return seed
  end

  -- Existing saves retain their own seed. Fresh-save reseeding is registered
  -- below, after the randomizer builders are defined, so dependent caches and
  -- trainer registry rows can be rebuilt immediately for the new playthrough.
  mod.events:on("save.loaded", function() persistFreshPlaythroughSeed(false) end)

  local Pokemon = require("src.core.game3.pokemon")

  -- Global Gen-3 ability randomization. Gen 3's runtime supports two ability
  -- slots per species; we assign two distinct valid Gen-3 abilities to every
  -- species. Shedinja (National Dex 292) keeps its native Wonder Guard slot.
  -- Since Pokemon.abilityId() delegates to Pokemon.abilities(), this covers
  -- wild, party, trainer, gift, egg, and scripted-created Pokémon consistently.
  local nativeAbilities = Pokemon.abilities
  local abilityPairs = {}
  local function abilityRand(seed)
    seed = (tonumber(seed) or 1) % 2147483647
    if seed <= 0 then seed = 1 end
    seed = (seed * 48271) % 2147483647
    return seed, seed % 77 + 1
  end
  local function randomizedAbilityPair(species)
    species = tonumber(species)
    if not species then return {0, 0} end
    local national = Pokemon.national(species)
    if national == 292 then return nativeAbilities(species) end
    if abilityPairs[species] then return {abilityPairs[species][1], abilityPairs[species][2]} end
    local seed = (activeSeed()) + species * 7919
    local _, a1 = abilityRand(seed)
    local _, a2 = abilityRand(seed + 104729)
    if a2 == a1 then a2 = (a2 % 77) + 1 end
    abilityPairs[species] = {a1, a2}
    return {a1, a2}
  end
  Pokemon.abilities = randomizedAbilityPair
  if type(Pokemon.invalidate) == "function" then pcall(Pokemon.invalidate) end
  local Schemas = require("src.mods.Schemas")
  local extendedTypes = assert(load(assert(mod:read("extended_types.lua")), "@extended_types.lua"))()
  local formData = assert(load(assert(mod:read("form_data.lua")), "@form_data.lua"))()

  -- The official 1025Dex deliberately leaves alternate forms outside its
  -- Gen3 registry.  Crazy owns the runtime bridge: no 1025Dex files are
  -- replaced or modified on disk.
  local formSlots = {}
  local nextFormSlot = FORM_SLOT_START
  local formByInternal = {}
  local formByNational = {}
  local formById = {}
  local formSourceByInternal = {}
  local formIds = {}

  local function normalizeTypeName(name)
    name = type(name) == "string" and name:upper() or nil
    if name == "PSYCHIC_TYPE" then return "PSYCHIC" end
    if name == "NORMAL_TYPE" then return "NORMAL" end
    return name
  end

  local function normalizedTypes(list)
    local out = {}
    for _, t in ipairs(list or {}) do
      local n = normalizeTypeName(t)
      if n and n ~= "MYSTERY" then out[#out + 1] = n end
    end
    return out
  end

  local function isGigantamaxKey(key)
    key = type(key) == "string" and key:upper() or ""
    return key:find("GMAX", 1, true) ~= nil
      or key:find("GIGANTAMAX", 1, true) ~= nil
  end

  local function allocateFormSlots()
    local rows = {}
    for id, source in pairs(formData) do
      if type(source) == "table" and type(source.dex) == "number"
          and not isGigantamaxKey(id) then
        rows[#rows + 1] = { id = id, dex = source.dex, source = source }
      end
    end
    table.sort(rows, function(a, b)
      if a.dex == b.dex then return a.id < b.id end
      return a.dex < b.dex
    end)
    for _, row in ipairs(rows) do
      formSlots[row.dex] = nextFormSlot
      nextFormSlot = nextFormSlot + 1
      formByNational[row.dex] = nextFormSlot - 1
      formByInternal[nextFormSlot - 1] = row.dex
      formById[row.id] = row.source
      formIds[#formIds + 1] = row.id
    end
    mod.log:info("Crazy runtime form bridge: %d alternate forms registered; Gigantamax excluded", #formIds)
  end

  allocateFormSlots()

  -- Lift the stale Gen3 species-index validation ceiling for this process only.
  -- The stock 1025Dex already does the same kind of runtime compatibility shim
  -- for its 1025 species; Crazy extends it to the 330 non-GMAX form slots it
  -- owns here. Nothing is written to Gen1Recomp on disk.
  local maxFormSlot = math.max(FORM_SLOT_START, nextFormSlot - 1)
  do
    local fields = Schemas and Schemas.REGISTRIES and Schemas.REGISTRIES.pokemon
      and Schemas.REGISTRIES.pokemon.gen3Fields
    if fields and Schemas.f and Schemas.f.opt and Schemas.f.int then
      fields.index = Schemas.f.opt(Schemas.f.int(1, maxFormSlot))
    else
      mod.log:warn("Crazy runtime form bridge: species-cap compatibility shim unavailable")
    end
  end

  local function cloneTable(t)
    local out = {}
    for k, v in pairs(t or {}) do
      if type(v) == "table" then
        local nested = {}
        for nk, nv in pairs(v) do nested[nk] = nv end
        out[k] = nested
      else
        out[k] = v
      end
    end
    return out
  end

  local function formRecord(id, source, slot)
    local entry = source.dexEntry or {}
    local stats = source.baseStats or {}
    return {
      id = id,
      name = (source.name or id):upper(),
      dex = source.dex,
      index = slot,
      types = normalizedTypes(source.types),
      baseStats = {
        hp = stats.hp or 1,
        attack = stats.attack or 1,
        defense = stats.defense or 1,
        speed = stats.speed or 1,
        specialAttack = source.spAttack or stats.special or 1,
        specialDefense = source.spDefense or stats.special or 1,
      },
      catchRate = source.catchRate or 0,
      baseExp = source.baseExp or 0,
      growthRate = source.growthRate or "MEDIUM_FAST",
      -- The raw form learnset is intentionally not written here. Its move
      -- names may be modern/non-engine names. Crazy writes a fully executable
      -- randomized numeric Gen3 learnset immediately after registration.
      learnset = {},
      tmhm = {},
      evolutions = {},
      dexEntry = {
        kind = entry.kind or "",
        height = math.floor((tonumber(entry.heightM) or 0) * 10 + 0.5),
        weight = math.floor((tonumber(entry.weightKg) or 0) * 10 + 0.5),
      },
      spriteFront = "data/generated/gba/pokemon/front/" .. tostring(slot) .. ".rgba",
      spriteBack = "data/generated/gba/pokemon/back/" .. tostring(slot) .. ".rgba",
    }
  end

  local function registerRuntimeForms()
    local records, ops = {}, {}
    for id, source in pairs(formData) do
      if not isGigantamaxKey(id) then
        local slot = formSlots[source.dex]
        if slot then
          local row = formRecord(id, source, slot)
          records[id], ops[id] = row, true
        end
      end
    end
    local registry = { ops = ops, get = function(_, id) return records[id] end }

    if not Pokemon._names then Pokemon.install(Pokemon._cache) end
    local names = {}
    for slot, name in pairs(Pokemon._names or {}) do names[slot] = name end
    for id, row in pairs(records) do names[row.index] = row.name end
    Pokemon._names = names

    Schemas.REGISTRIES.pokemon.gen3Write(Pokemon, registry)
    Pokemon._byName = Pokemon._byName or {}
    Pokemon._national = Pokemon._national or {}
    Pokemon._national.toSpecies = Pokemon._national.toSpecies or {}
    Pokemon._national.toNational = Pokemon._national.toNational or {}
    for id, row in pairs(records) do
      local slot = row.index
      Pokemon._names[slot] = row.name
      Pokemon._byName[id:upper():gsub("[^A-Z0-9]", "")] = slot
      Pokemon._byName[row.name:upper():gsub("[^A-Z0-9]", "")] = slot
      Pokemon._national.toSpecies[row.dex] = slot
      Pokemon._national.toNational[slot] = row.dex
    end
    return records
  end

  local runtimeFormRecords = registerRuntimeForms()

  local function hashString(s, seed)
    local h = (tonumber(seed) or 20261006) % LCG_MOD
    if h <= 0 then h = 1 end
    for i = 1, #s do h = (h * 31 + s:byte(i)) % LCG_MOD end
    return h
  end

  local function nextRand(state)
    state.value = (state.value * 48271) % LCG_MOD
    return state.value
  end

  local poolCache = {}
  local moveCache = {}
  local learnsetCache = {}
  local trainerCache = {}
  local trainerPoolCache = {}
  local moveCatalog = nil
  local speciesCatalog
  local encounterStates = {}
  local tableForGuard = false

  local applyRandomMoves

  -- If the Gen3 Pokemon pack is reloaded later, the stock 1025Dex rebuilds its
  -- base species but intentionally has no form writer. Re-apply our in-memory
  -- form bridge first, then rebuild the randomized learnsets.
  Pokemon.onReload(function()
    runtimeFormRecords = registerRuntimeForms()
    if mod.options:get("randomize_moves") ~= false then
      learnsetCache = {}
      if type(applyRandomMoves) == "function" then applyRandomMoves() end
    end
  end, "crazy_runtime_forms_0421")

  local function validInternal(id, expectedNational)
    id = tonumber(id)
    if not id or id < 1 then return false end
    local okName, name = pcall(Pokemon.keyName, id)
    if not okName or type(name) ~= "string" or name == "" then return false end
    local okNat, nat = pcall(Pokemon.national, id)
    nat = okNat and tonumber(nat) or nil
    if not nat or nat < 1 then return false end
    if expectedNational ~= nil then return nat == tonumber(expectedNational) end
    return true
  end

  local function isMegaOrGigantamax(internal)
    local ok, name = pcall(Pokemon.keyName, internal)
    if not ok or type(name) ~= "string" then return false end
    local key = name:upper()
    return key:find("MEGA", 1, true) ~= nil
      or key:find("GMAX", 1, true) ~= nil
      or key:find("GIGANTAMAX", 1, true) ~= nil
  end

  local function buildSpeciesCatalog()
    local byNational, byInternal, nationals = {}, {}, {}
    local function add(national, internal)
      national, internal = tonumber(national), tonumber(internal)
      if not national or not internal or byNational[national] then return end
      if not validInternal(internal, national) then return end
      if mod.options:get("exclude_gmax") and isGigantamaxKey(Pokemon.keyName(internal)) then return end
      byNational[national] = internal
      byInternal[internal] = national
      nationals[#nationals + 1] = national
    end

    for national = 1, SPECIES_COUNT do
      local ok, internal = pcall(Pokemon.speciesFromNational, national)
      if ok then add(national, internal) end
    end
    for national, internal in pairs(Pokemon._national and Pokemon._national.toSpecies or {}) do
      national, internal = tonumber(national), tonumber(internal)
      if national and national > SPECIES_COUNT then add(national, internal) end
    end
    table.sort(nationals)
    speciesCatalog = { byNational = byNational, byInternal = byInternal, nationals = nationals }
    mod.log:info("Crazy species pool: %d entries (1025 base + runtime forms; GMAX excluded)", #nationals)
    return speciesCatalog
  end

  local function catalog()
    if not speciesCatalog then return buildSpeciesCatalog() end
    return speciesCatalog
  end

  local function internalFromNational(national)
    return catalog().byNational[tonumber(national)]
  end

  local function nationalFromInternal(internal)
    local n = catalog().byInternal[tonumber(internal)]
    if n then return n end
    local ok, nat = pcall(Pokemon.national, internal)
    return ok and tonumber(nat) or nil
  end

  local function formSource(internal)
    return formSourceByInternal[tonumber(internal)]
  end

  local function sourceTypesForSpecies(internal)
    local source = formSource(internal)
    if source then return normalizedTypes(source.types) end
    local national = nationalFromInternal(internal)
    if national then
      local ext = extendedTypes[tonumber(national)]
      if type(ext) == "table" and #ext > 0 then return normalizedTypes(ext) end
    end
    local raw = Pokemon.types(internal)
    local out = {}
    local typeNames = Schemas and Schemas.gen3View and Schemas.gen3View.TYPES or {}
    for _, id in ipairs(raw or {}) do
      local n = typeNames[tonumber(id)]
      if n and n ~= "MYSTERY" then out[#out + 1] = n end
    end
    return out
  end

  local function buildMoveCatalog()
    if moveCatalog then return moveCatalog end
    local all, damage, byType = {}, {}, {}
    for id = 1, 354 do
      local row = Pokemon.battleMove(id)
      -- STRUGGLE is the engine fallback, never a randomized learnset move.
      if id ~= 165 and type(row) == "table" and tonumber(row.pp or 0) > 0 then
        local move = {
          id = id,
          type = normalizeTypeName(row.type) or "NORMAL",
          power = tonumber(row.power or 0) or 0,
        }
        all[#all + 1] = move
        byType[move.type] = byType[move.type] or {}
        byType[move.type][#byType[move.type] + 1] = move
        if move.power > 0 then damage[#damage + 1] = move end
      end
    end
    moveCatalog = { all = all, damage = damage, byType = byType }
    mod.log:info("Crazy executable move pool: %d Gen3 moves (%d damaging); 1025Dex Gen3-compatible data uses this native battle layer", #all, #damage)
    return moveCatalog
  end

  local function affinityPool(catalogue, typeName)
    -- Fairy is a first-class 1025Dex type for species/theme selection. The
    -- Gen3 battle engine has no native Fairy move type, so its executable
    -- move pool uses the safest curated fallback rather than inventing a
    -- non-existent battle type.  1025Dex's Gen3 compatibility substitutions
    -- are represented by the native executable move IDs below.
    if typeName == "FAIRY" then
      return catalogue.byType.NORMAL or catalogue.all
    end
    return catalogue.byType[typeName] or catalogue.byType.NORMAL or catalogue.all
  end

  local function chooseMove(pool, state, used)
    if type(pool) ~= "table" or #pool == 0 then return nil end
    local start = (nextRand(state) % #pool) + 1
    for offset = 0, #pool - 1 do
      local move = pool[((start - 1 + offset) % #pool) + 1]
      if not used[move.id] then return move end
    end
    return nil
  end

  local function chooseFrom(pool, state, used)
    local move = chooseMove(pool, state, used)
    if move then used[move.id] = true end
    return move
  end

  local function roundCount(n, ratio)
    return math.floor(n * ratio + 0.5)
  end

  local function buildRandomMoveIds(internal, count)
    local c = buildMoveCatalog()
    local types = sourceTypesForSpecies(internal)
    local affinity = mod.options:get("type_affinity") ~= false
    local seed = activeSeed()
    local state = { value = hashString("moves|" .. tostring(nationalFromInternal(internal) or internal), seed) }
    if state.value <= 0 then state.value = 1 end
    count = math.max(4, tonumber(count) or 4)

    local out, used = {}, {}
    local buckets = {}
    if affinity and #types >= 2 and types[1] ~= types[2] then
      local n1 = math.floor(count / 2 + 0.5)
      local n2 = count - n1
      buckets = {
        { type = types[1], count = n1 },
        { type = types[2], count = n2 },
      }
    elseif affinity and #types >= 1 then
      buckets = {
        { type = types[1], count = roundCount(count, 0.40) },
        { type = nil, count = count - roundCount(count, 0.40) },
      }
    else
      buckets = { { type = nil, count = count } }
    end

    local desiredDamage = roundCount(count, 0.70)
    local assignedDamage = 0
    for i, bucket in ipairs(buckets) do
      bucket.damage = roundCount(bucket.count, 0.70)
      assignedDamage = assignedDamage + bucket.damage
      if i == #buckets and assignedDamage ~= desiredDamage then
        bucket.damage = math.max(0, bucket.damage + desiredDamage - assignedDamage)
      end
    end

    local function take(bucket, wantDamage)
      local pool
      if bucket.type then
        local typed = affinityPool(c, bucket.type)
        if wantDamage then
          local typedDamage = {}
          for _, mv in ipairs(typed) do if mv.power > 0 then typedDamage[#typedDamage + 1] = mv end end
          pool = #typedDamage > 0 and typedDamage or typed
        else
          pool = typed
        end
      else
        pool = wantDamage and c.damage or c.all
      end
      return chooseMove(pool, state, used)
    end

    for _, bucket in ipairs(buckets) do
      for _ = 1, bucket.count do
        local wantDamage = bucket.damage > 0
        local move = take(bucket, wantDamage)
        if not move then
          -- If a type has run out of unique moves, keep the global damage/type
          -- requirement as intact as possible while guaranteeing a legal move.
          move = chooseMove(wantDamage and c.damage or c.all, state, used)
        end
        if not move then move = chooseMove(c.all, state, used) end
        if move then used[move.id] = true; out[#out + 1] = move.id end
        if wantDamage then bucket.damage = bucket.damage - 1 end
      end
    end

    while #out < count do
      local move = chooseMove(c.all, state, used)
      if not move then break end
      used[move.id] = true
      out[#out + 1] = move.id
    end
    return out
  end

  -- Keep a reference to the engine/provider learnset reader.  The live Pokemon
  -- cache can be rebuilt later by Gen1Recomp/1025Dex; our wrapper below must
  -- never call itself while reconstructing the randomized progression.
  local originalLearnset = Pokemon.learnset

  local function baseLearnsetFor(internal)
    local set = originalLearnset(internal)
    local out = {}
    for _, row in ipairs(set or {}) do
      local lv = tonumber(row[1] or row.level) or 1
      out[#out + 1] = { level = math.max(1, math.min(100, lv)) }
    end
    return out
  end

  local function formLearnsetLevels(internal)
    local source = formSource(internal)
    if not source then return baseLearnsetFor(internal) end
    local raw = source.learnset
    if type(raw) ~= "table" or #raw == 0 then
      local base = source.baseSpecies and Pokemon.speciesFromName(source.baseSpecies) or nil
      if base then return baseLearnsetFor(base) end
      return baseLearnsetFor(internal)
    end
    local out = {}
    for _, row in ipairs(raw) do
      if type(row) == "table" then
        local lv = tonumber(row.level or row[1]) or 1
        out[#out + 1] = { level = math.max(1, math.min(100, lv)) }
      end
    end
    return out
  end

  local function ensureFourEarly(rows)
    local out = rows
    table.sort(out, function(a, b) return a.level < b.level end)
    while #out < 4 do out[#out + 1] = { level = 1 } end
    for i = 1, math.min(4, #out) do out[i].level = 1 end
    return out
  end

  local function randomizeSpeciesLearnset(internal)
    internal = tonumber(internal)
    if not internal then return nil end
    if learnsetCache[internal] then return learnsetCache[internal] end
    local levels = formLearnsetLevels(internal)
    levels = ensureFourEarly(levels)
    local ids = buildRandomMoveIds(internal, #levels)
    local rows = {}
    for i, lv in ipairs(levels) do
      local moveId = ids[i] or ids[#ids]
      if moveId then rows[#rows + 1] = { lv.level, moveId } end
    end
    if #rows < 4 then
      local fallback = buildRandomMoveIds(internal, 4)
      rows = {}
      for i = 1, 4 do rows[i] = { 1, fallback[i] } end
    end
    learnsetCache[internal] = rows
    return rows
  end

  -- Hard runtime safety net for every randomized species.  Some Game3/1025Dex
  -- reload paths rebuild Pokemon._learnsets after a mod has already patched the
  -- table.  Battle initialization reads Pokemon.learnset()/movesAtLevel(), so
  -- wrapping the public reader is the reliable final guard: every eligible
  -- species always exposes a legal progression with four moves from level 1.
  local function installLearnsetSafety()
    if Pokemon.__crazyLearnsetSafety042 then return end
    local safetyOriginal = Pokemon.learnset
    Pokemon.learnset = function(species)
      local sp = species
      if type(sp) == "table" then sp = Pokemon.speciesOf(sp) end
      if type(sp) == "string" then sp = Pokemon.speciesFromName(sp) or tonumber(sp) end
      sp = tonumber(sp)
      if mod.options:get("randomize_moves") ~= false and sp then
        local cached = learnsetCache[sp]
        if cached and #cached > 0 then return cached end
        local rows = randomizeSpeciesLearnset(sp)
        if rows and #rows > 0 then return rows end
        -- Last-resort single executable move. This path should be unreachable,
        -- but prevents a malformed/unknown species from entering battle with
        -- an empty moveset.
        local fallback = buildRandomMoveIds(sp, 4)
        local safe = {}
        for i = 1, 4 do
          safe[i] = { 1, fallback[i] or 1 }
        end
        learnsetCache[sp] = safe
        return safe
      end
      return safetyOriginal(species)
    end
    Pokemon.__crazyLearnsetSafety042 = true
  end

  applyRandomMoves = function()
    if mod.options:get("randomize_moves") == false then return end
    if not Pokemon._learnsets then Pokemon.learnset(1) end
    if type(Pokemon._learnsets) ~= "table" then return end
    learnsetCache = {}
    local count = 0
    local c = catalog()
    for _, internal in pairs(c.byInternal) do
      local rows = randomizeSpeciesLearnset(internal)
      if rows and #rows >= 4 then
        Pokemon._learnsets[internal] = rows
        count = count + 1
      end
    end
    mod.log:info("Crazy complete learnset randomizer: %d species/forms received a randomized full progression", count)
  end

  local function randomizedMovesFor(species)
    if mod.options:get("randomize_moves") == false then return nil end
    local sp = tonumber(species)
    if not sp then return nil end
    local rows = randomizeSpeciesLearnset(sp)
    if not rows then return nil end
    local moves, pp, maxPp = Pokemon.movesAtLevel(sp, 100)
    if not moves or #moves == 0 then return nil end
    pp, maxPp = {}, {}
    for i, id in ipairs(moves) do
      local n = Pokemon.movePp(id)
      pp[i], maxPp[i] = n, n
    end
    return moves, pp, maxPp
  end

  local function installRandomMoveHooks()
    if not Pokemon.__crazyRandomMovesHook040 then
      Pokemon.onReload(function()
        installLearnsetSafety()
        if mod.options:get("randomize_moves") ~= false then applyRandomMoves() end
      end, "crazy_random_moves_042")
      Pokemon.__crazyRandomMovesHook040 = true
    end
    dex.exports.vanillaWildMoves = function(species, level)
      if mod.options:get("randomize_moves") ~= false then
        local sp = tonumber(species)
        if sp then
          randomizeSpeciesLearnset(sp)
          local moves, pp, maxPp = Pokemon.movesAtLevel(sp, tonumber(level) or 1)
          if moves and #moves > 0 then
            pp, maxPp = {}, {}
            for i, id in ipairs(moves) do
              local n = Pokemon.movePp(id); pp[i], maxPp[i] = n, n end
            return moves, pp, maxPp
          end
        end
      end
      return Pokemon.movesAtLevel(species, tonumber(level) or 1)
    end
    installLearnsetSafety()
    applyRandomMoves()
  end

  local rerollSerial = 0
  local function rerollSeed()
    local current = activeSeed()
    local now = os.time() or 0
    local clock = 0
    if love and love.timer and love.timer.getTime then clock = math.floor(love.timer.getTime() * 1000000) end
    rerollSerial = rerollSerial + 1
    local state = (current * 48271 + now * 1103515245 + clock + rerollSerial * 104729) % (LCG_MOD - 1)
    if state <= 0 then state = 1 end
    if state == current then state = (state % (LCG_MOD - 1)) + 1 end
    return math.floor(state)
  end

  local function saveSeed(seed)
    seed = math.max(1, math.min(LCG_MOD - 1, math.floor(tonumber(seed) or activeSeed())))
    activeSeedOverride = seed
    if mod.save and mod.save.set then mod.save:set("crazy_seed", seed) end
    -- Keep the global option as the next-new-game fallback only; do not write
    -- the active seed into global mod options or other game save option blobs.
    local game = mod.game
    if game and type(game.save) == "table" then
      game.save.modData = game.save.modData or {}
      game.save.modData[mod.id] = game.save.modData[mod.id] or {}
      game.save.modData[mod.id].crazy_seed = seed
    end
    if mod.options:get("reroll_seed") ~= "idle" then pcall(function() mod.options:set("reroll_seed", "idle") end) end
  end

  local function shuffledNationals(key, baseOnly)
    local base = {}
    for _, national in ipairs(catalog().nationals) do
      if not baseOnly or national <= SPECIES_COUNT then base[#base + 1] = national end
    end
    local state = hashString(key, activeSeed())
    for i = #base, 2, -1 do
      state = (state * 48271) % LCG_MOD
      local j = (state % i) + 1
      base[i], base[j] = base[j], base[i]
    end
    return base
  end

  local function liveDexPool(mapId)
    tableForGuard = true
    local ok, pools = pcall(originalDexNav, mapId)
    tableForGuard = false
    return ok and pools or nil
  end

  local function poolArea(mapId, terrain)
    if not mapId then return nil, terrain end
    local pools = liveDexPool(mapId)
    if type(pools) ~= "table" then return nil, terrain end
    local t = terrain
    if t == "fishing" or t == "rocks" then t = "water" end
    if t ~= "water" then t = "land" end
    local area = pools[t]
    if type(area) ~= "table" or type(area.slots) ~= "table" or #area.slots == 0 then return nil, t end
    return area, t
  end

  local function uniqueSourceNationals(area)
    local out, seen = {}, {}
    for _, slot in ipairs(area and area.slots or {}) do
      local internal = tonumber(slot and slot.species)
      local national = internal and nationalFromInternal(internal)
      if national and not seen[national] then seen[national] = true; out[#out + 1] = national end
    end
    table.sort(out)
    return out
  end

  local function encounterPoolSize(terrain)
    -- Land/grass routes get twelve distinct randomized species per map.
    -- Surf, fishing and Rock Smash share a five-species pool, independent of
    -- time of day. Future special encounter categories can opt into size 5.
    if terrain == "land" or terrain == "grass" then return 12 end
    return 5
  end

  local function targetPool(mapId, terrain, sourceArea, baseOnly)
    local normalizedTerrain = (terrain == "grass") and "land" or ((terrain == "rocks" or terrain == "fishing") and "water" or terrain)
    local desiredCount = (normalizedTerrain == "land") and 12 or 5
    local key = table.concat({ tostring(activeSeed()), tostring(mapId or "?"), tostring(normalizedTerrain or "land"), tostring(mod.options:get("scope") or "all"), baseOnly and "base" or "all", tostring(desiredCount) }, "|")
    if poolCache[key] then return poolCache[key] end

    local sourceNationals = uniqueSourceNationals(sourceArea)
    if baseOnly then
      local filteredSource = {}
      for _, n in ipairs(sourceNationals) do if n <= SPECIES_COUNT then filteredSource[#filteredSource + 1] = n end end
      sourceNationals = filteredSource
    end

    local candidates = {}
    if mod.options:get("scope") == "active" and #sourceNationals >= desiredCount then
      candidates = sourceNationals
    else
      -- The active encounter table often contains only five native slots; it
      -- cannot provide twelve distinct route species. Fall back to the active
      -- 1025Dex catalog in that case so the requested pool size is respected.
      for _, n in ipairs(catalog().nationals) do
        if not baseOnly or n <= SPECIES_COUNT then candidates[#candidates + 1] = n end
      end
    end

    local shuffled = {}
    for i, n in ipairs(candidates) do shuffled[i] = n end
    local state = { value = hashString(key, activeSeed()) }
    for i = #shuffled, 2, -1 do
      local j = (nextRand(state) % i) + 1
      shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
    end

    local out, seenInternal = {}, {}
    for _, n in ipairs(shuffled) do
      local internal = internalFromNational(n)
      if internal and validInternal(internal) and not seenInternal[internal] then
        seenInternal[internal] = true
        out[#out + 1] = n
        if #out >= math.min(desiredCount, #candidates) then break end
      end
    end
    poolCache[key] = out
    return out
  end

  local function nextEncounterTarget(mapId, terrain, pool)
    if #pool == 0 then return nil end
    local key = table.concat({ tostring(mapId or "?"), tostring(terrain or "land") }, "|")
    local state = encounterStates[key]
    if not state then
      state = { value = hashString(key, activeSeed()), last = nil }
      if state.value <= 0 then state.value = 1 end
      encounterStates[key] = state
    end
    local index = (nextRand(state) % #pool) + 1
    local selected = pool[index]
    -- Avoid immediate duplicates where possible without cycling through the
    -- pool in a fixed order. Repeats remain possible after intervening species.
    if #pool > 1 and selected == state.last then
      index = (index % #pool) + 1
      selected = pool[index]
    end
    state.last = selected
    return selected
  end

  local function rewriteEncounter(encounter, game, opts)
    if type(encounter) ~= "table" then return encounter, false end
    -- Static/scripted/legendary encounters are included in the public randomizer pool.
    if encounter.noRandomize == true or encounter.__crazyRandomized == true then return encounter, false end
    local mapId = encounter.__completeDexMap
    if not mapId then
      local Runtime = package.loaded["src.core.game3.runtime"]
      local session = Runtime and Runtime.getSession and Runtime.getSession()
      mapId = session and session.map or (game and game.currentMap)
    end
    local terrain = encounter.__completeDexTerrain or (opts and opts.terrain) or "land"
    local source = tonumber(encounter.species or encounter.speciesId or encounter.id)
    if not source then return encounter, false end
    local area, mappedTerrain = poolArea(mapId, terrain)
    if mod.options:get("scope") == "active" and not area then return encounter, false end
    local pool = targetPool(mapId, mappedTerrain, area)
    local national = nextEncounterTarget(mapId, mappedTerrain, pool)
    local selected = national and internalFromNational(national) or source
    if not selected or not validInternal(selected) then return encounter, false end
    local out = cloneTable(encounter); out.species, out.speciesId = selected, selected
    return out, selected ~= source
  end

  local function randomizedEncounterTable(mapId)
    local ok, native = pcall(nativeTableFor, mapId)
    if not ok or type(native) ~= "table" or tableForGuard then return native end
    local out = {}
    for k, v in pairs(native) do out[k] = type(v) == "table" and cloneTable(v) or v end
    for _, terrain in ipairs({ "land", "water", "rocks", "fishing", "grass" }) do
      local area = native[terrain]
      local slots = type(area) == "table" and (area.slots or area.mons) or nil
      if type(slots) == "table" and #slots > 0 then
        local mapped = terrain == "grass" and "land" or ((terrain == "rocks" or terrain == "fishing") and "water" or terrain)
        local targets = targetPool(mapId, mapped, nil, mod.options:get("untamed_compat") == true)
        local copyArea = cloneTable(area); copyArea.slots = {}
        for i, slot in ipairs(slots) do
          local target = (#targets > 0) and targets[(nextRand({ value = hashString(tostring(mapId) .. "|" .. tostring(terrain) .. "|slot|" .. tostring(i), activeSeed()) }) % #targets) + 1] or nil
          local internal = target and internalFromNational(target)
          local copySlot = cloneTable(slot)
          if internal and validInternal(internal) then
            copySlot.species, copySlot.speciesId = internal, internal
            copySlot.__crazyRandomized = true
          end
          copyArea.slots[#copyArea.slots + 1] = copySlot
        end
        out[terrain] = copyArea
      end
    end
    out.__crazyRandomizedTable = true
    return out
  end

  local okEncounters, Encounters = pcall(require, "src.core.game3.encounters")
  if not okEncounters or type(Encounters) ~= "table" or type(Encounters.tableFor) ~= "function" then
    mod.log:error("Gen3 Encounters.tableFor is unavailable; Crazy Randomizer cannot start")
    return
  end
  local nativeTableFor = Encounters.tableFor
  -- Preserve the native encounter table contract. WildFollowers needs the
  -- native slot metadata to build overworld actors and already calls the
  -- supported chooseWildEncounter export for randomized species.

  local function randomizedDexNav(mapId)
    local pools = liveDexPool(mapId)
    if type(pools) ~= "table" then return pools end
    local out = { numbering = "national" }
    for k, v in pairs(pools) do
      if k ~= "numbering" then out[k] = type(v) == "table" and cloneTable(v) or v end
    end
    for _, terrain in ipairs({ "land", "water" }) do
      local area = pools[terrain]
      if type(area) == "table" and type(area.slots) == "table" and #area.slots > 0 then
        local targets = targetPool(mapId, terrain, area)
        local copyArea = cloneTable(area); copyArea.slots = {}
        for i, national in ipairs(targets) do
          local internal = internalFromNational(national)
          if internal and validInternal(internal) then
            local template = area.slots[((i - 1) % #area.slots) + 1]
            local copySlot = cloneTable(template)
            -- dexnavEncounters is a public API using National Dex numbers.
            -- Convert to engine-native IDs only at the point of use.
            copySlot.species = national
            copySlot.speciesId = nil
            copySlot.minLevel, copySlot.maxLevel = template.minLevel, template.maxLevel
            copyArea.slots[#copyArea.slots + 1] = copySlot
          end
        end
        out[terrain] = copyArea
      end
    end
    return out
  end

  dex.exports.dexnavEncounters = randomizedDexNav
  dex.exports.chooseWildEncounter = function(mapId, terrain, nativeLevel)
    local baseId, baseSpecies, level, catchRate = originalChoose(mapId, terrain, nativeLevel)
    if not baseSpecies then return baseId, baseSpecies, level, catchRate end
    local area, mappedTerrain = poolArea(mapId, terrain)
    if not area then return baseId, baseSpecies, level, catchRate end
    local targets = targetPool(mapId, mappedTerrain, area)
    local targetNational = nextEncounterTarget(mapId, mappedTerrain, targets)
    local targetInternal = targetNational and internalFromNational(targetNational)
    if not targetInternal or not validInternal(targetInternal) then return baseId, baseSpecies, level, catchRate end
    return baseId, targetInternal, level, catchRate
  end

  local TRAINER_TYPES = {
    "NORMAL", "FIRE", "WATER", "ELECTRIC", "GRASS", "ICE", "FIGHTING", "POISON",
    "GROUND", "FLYING", "PSYCHIC", "BUG", "ROCK", "GHOST", "DRAGON", "DARK", "STEEL", "FAIRY"
  }

  local function trainerLabel(original, trainerId)
    local id = tostring(trainerId or ""):upper()
    local name = tostring(original and original.name or ""):upper()
    local className = tostring(original and original.className or ""):upper()
    return id .. " " .. name .. " " .. className
  end

  local function trainerRole(original, trainerId)
    local label = trainerLabel(original, trainerId)
    local gymNames = {
      ROXANNE=true, BRAWLY=true, WATTSON=true, FLANNERY=true, NORMAN=true,
      WINONA=true, TATE=true, LIZA=true, WALLACE=true, JUAN=true,
      BROCK=true, MISTY=true, SURGE=true, ERIKA=true, KOGA=true,
      SABRINA=true, BLAINE=true, GIOVANNI=true
    }
    for n in pairs(gymNames) do
      if label:find(n, 1, true) and (label:find("LEADER",1,true) or label:find("GYM",1,true)) then
        return "gym_leader"
      end
    end
    if label:find("LEADER", 1, true) or label:find("GYM", 1, true) then return "gym_leader" end
    if label:find("ELITE", 1, true) or label:find("CHAMPION", 1, true)
        or label:find("LORELEI",1,true) or label:find("BRUNO",1,true)
        or label:find("AGATHA",1,true) or label:find("LANCE",1,true)
        or label:find("SIDNEY",1,true) or label:find("PHOEBE",1,true)
        or label:find("GLACIA",1,true) or label:find("DRAKE",1,true)
        or label:find("RIVAL",1,true) then return "important" end
    if label:find("ADMIN",1,true) or label:find("BOSS",1,true)
        or label:find("ARCHIE",1,true) or label:find("MAXIE",1,true)
        or label:find("GIOVANNI",1,true) then return "important" end
    return "common"
  end

  local speciesIdentityCache = {}

  local function speciesIdentity(internal)
    internal = tonumber(internal)
    if speciesIdentityCache[internal] then return speciesIdentityCache[internal] end
    local source = formSource(internal)
    local identity
    if source and source.baseSpecies then
      local base = Pokemon.speciesFromName(source.baseSpecies)
      if base then identity = "BASE:" .. tostring(nationalFromInternal(base) or base) end
    end
    identity = identity or ("NAT:" .. tostring(nationalFromInternal(internal) or internal))
    speciesIdentityCache[internal] = identity
    return identity
  end

  local function speciesHasType(internal, typeName)
    for _, t in ipairs(sourceTypesForSpecies(internal) or {}) do
      if t == typeName then return true end
    end
    return false
  end

  local function trainerCandidatePool(desiredType)
    local key = desiredType or "__ALL__"
    if trainerPoolCache[key] then return trainerPoolCache[key] end
    local c = catalog()
    local pool = {}
    for _, n in ipairs(c.nationals) do
      local internal = internalFromNational(n)
      if internal then
        local source = formSource(internal)
        local gmax = isGigantamaxKey(source and source.id or Pokemon.keyName(internal))
        local mega = isMegaOrGigantamax(internal) and not gmax
        if not gmax and (mod.options:get("trainer_allow_megas") == true or not mega) then
          local types = sourceTypesForSpecies(internal)
          local matches = not desiredType
          if desiredType then
            for _, t in ipairs(types or {}) do
              if t == desiredType then matches = true; break end
            end
          end
          if matches then
            local identity = speciesIdentity(internal)
            pool[#pool + 1] = { internal = internal, identity = identity }
          end
        end
      end
    end
    trainerPoolCache[key] = pool
    return pool
  end

  local function randomTrainerSpecies(trainerId, slot, desiredType, used)
    local pool = trainerCandidatePool(desiredType)
    local eligible = pool
    if used and next(used) ~= nil then
      eligible = {}
      for _, candidate in ipairs(pool) do
        if not used[candidate.identity] then eligible[#eligible + 1] = candidate end
      end
    end
    -- A gym leader's type is a hard constraint. Never silently fall back to
    -- an unrelated type when a themed candidate pool is exhausted.
    if #eligible == 0 then return nil end
    local state = hashString("trainer|" .. tostring(trainerId) .. "|" .. tostring(slot) .. "|" .. tostring(desiredType or "ALL"), activeSeed())
    return eligible[(state % #eligible) + 1].internal
  end

  local function moveNamesForIds(ids)
    local out = {}
    for _, id in ipairs(ids or {}) do
      local name = Pokemon._moveNames and Pokemon._moveNames[id]
      if type(name) == "string" and name ~= "" and name ~= "STRUGGLE" then out[#out + 1] = name end
    end
    return out
  end

  local function trainerMovesAtLevel(target, level)
    if mod.options:get("randomize_moves") == false then return nil end
    local moves = Pokemon.movesAtLevel(target, level)
    if type(moves) ~= "table" or #moves < 4 then
      local rows = randomizeSpeciesLearnset(target)
      local ids = {}
      for _, row in ipairs(rows or {}) do
        if (tonumber(row[1]) or 1) <= 1 and row[2] ~= 165 then ids[#ids + 1] = row[2] end
        if #ids >= 4 then break end
      end
      moves = ids
    end
    if type(moves) ~= "table" then return nil end
    local filtered = {}
    for _, id in ipairs(moves) do if id ~= 165 then filtered[#filtered + 1] = id end end
    if #filtered < 4 then
      local rows = randomizeSpeciesLearnset(target)
      for _, row in ipairs(rows or {}) do
        local id = row[2]
        if id and id ~= 165 then
          local seen = false
          for _, x in ipairs(filtered) do if x == id then seen = true break end end
          if not seen then filtered[#filtered + 1] = id end
        end
        if #filtered >= 4 then break end
      end
    end
    return filtered
  end

  local function chooseTrainerType(trainerId)
    local seed = activeSeed()
    local state = hashString("trainer-type|" .. tostring(trainerId), seed)
    return TRAINER_TYPES[(state % #TRAINER_TYPES) + 1]
  end

  local function isBattleFrontierTrainer(original, trainerId)
    local label = trainerLabel(original, trainerId)
    return label:find("FRONTIER", 1, true) ~= nil
      or label:find("BATTLE_TOWER", 1, true) ~= nil
      or label:find("BATTLE_FACTORY", 1, true) ~= nil
      or label:find("BATTLE_DOME", 1, true) ~= nil
      or label:find("BATTLE_PALACE", 1, true) ~= nil
      or label:find("BATTLE_ARENA", 1, true) ~= nil
      or label:find("BATTLE_PIKE", 1, true) ~= nil
      or label:find("BATTLE_PYRAMID", 1, true) ~= nil
  end

  local function isFirstRivalBattle(original, trainerId)
    local label = trainerLabel(original, trainerId)
    -- The first rival fight is inconsistently named across FRLG/RSE registry
    -- data (some rows only say BLUE/GARY or RIVAL, and omit the map name).
    -- Its vanilla party is one Pokémon in all supported Gen 3 games. Use that
    -- as a secondary discriminator so later multi-mon rival fights stay important.
    local rivalLike = label:find("RIVAL", 1, true) ~= nil
      or label:find("BLUE", 1, true) ~= nil
      or label:find("GARY", 1, true) ~= nil
      or label:find("BRENDAN", 1, true) ~= nil
      or label:find("MAY", 1, true) ~= nil
    if not rivalLike then return false end
    local party = original and original.party
    local partyCount = type(party) == "table" and #party or 0
    return label:find("OAKS_LAB", 1, true) ~= nil
      or label:find("ROUTE_103", 1, true) ~= nil
      or label:find("ROUTE_22", 1, true) ~= nil
      or label:find("PLAYER_HOUSE", 1, true) ~= nil
      or partyCount == 1
  end

  local function commonTrainerCount(trainerId, isDouble)
    local seed = activeSeed()
    -- Hash bucket 0 of 5 assigns exactly one fifth of the common-trainer IDs
    -- six Pokémon. Other common trainers are distributed over 1-5 (or 2-5
    -- in doubles), avoiding the old uniform 1-6 rule which yielded only 16.7%.
    local state = hashString("trainer-count|" .. tostring(trainerId), seed)
    if state % 5 == 0 then return 6 end
    local minCount = isDouble and 2 or 1
    local span = isDouble and 4 or 5
    return minCount + ((math.floor(state / 5) % span))
  end

  local function rebuildTrainerParty(original, trainerId)
    local role = trainerRole(original, trainerId)
    local mode = mod.options:get("trainer_party_mode") or "important6"
    local originalParty = original.party or {}
    local count
    local frontier = isBattleFrontierTrainer(original, trainerId)
    local firstRival = isFirstRivalBattle(original, trainerId)
    if frontier then
      -- Battle Frontier opponents are species-randomized, but their original
      -- party sizes are part of the facility rules and must not be changed.
      count = #originalParty
    elseif firstRival then
      count = 2
    elseif mode == "vanilla" then count = #originalParty
    elseif mode == "full6" then count = 6
    elseif role == "gym_leader" or role == "important" then count = 6
    else
      count = commonTrainerCount(trainerId, original.doubleBattle == true)
    end
    if original.doubleBattle and not frontier and not firstRival and mode ~= "vanilla" then
      if mode == "full6" or role == "gym_leader" or role == "important" then
        count = 6
      else
        count = commonTrainerCount(trainerId, true)
      end
    end
    count = math.max(1, math.min(6, count))

    local theme = role == "gym_leader" and chooseTrainerType(trainerId) or nil
    local used, party = {}, {}
    for slot = 1, count do
      local target = randomTrainerSpecies(trainerId, slot, theme, used)
      if not target then break end
      used[speciesIdentity(target)] = true
      local template = cloneTable(originalParty[((slot - 1) % math.max(1, #originalParty)) + 1] or {})
      template.species = Pokemon.keyName(target)
      local level = tonumber(template.level) or tonumber(original.lastLevel) or 5
      -- Trainer registry party slots are schema-strict in current Gen1Recomp.
      -- Moves are applied later through the trainer.party runtime hook so they
      -- reach BattleState.newTrainer without relying on an undeclared field.
      template.moves = nil
      party[#party + 1] = template
    end
    return party, theme, role
  end

  -- Returns true when a two-opponent battle is mandatory/inseparable rather
  -- than an optional simultaneous sight-line double.  Gen3 exposes the
  -- explicit double flag on trainer data and the trainer-battle opcode type;
  -- gym/important trainers are also treated as mandatory when they enter a
  -- two-opponent battle so their six-mon rule cannot be truncated.
  local function trainerRoleById(trainerId)
    local reg = mod.content and mod.content.trainers
    if not reg or type(reg.get) ~= "function" then return "common" end
    local ok, row = pcall(function() return reg:get(trainerId) end)
    if not ok or type(row) ~= "table" then return "common" end
    return trainerRole(row, trainerId)
  end

  local function trainerIsMandatoryDouble(trainerId)
    local role = trainerRoleById(trainerId)
    if role == "gym_leader" or role == "important" then return true end
    local reg = mod.content and mod.content.trainers
    if reg and type(reg.get) == "function" then
      local ok, row = pcall(function() return reg:get(trainerId) end)
      if ok and type(row) == "table" and row.doubleBattle == true then return true end
    end
    return false
  end

  local function twoOpponentMandatoryPair(trainerIdA, trainerIdB)
    return trainerIsMandatoryDouble(trainerIdA) or trainerIsMandatoryDouble(trainerIdB)
  end

  local function ensureTrainerPartyRows(foe, trainerId, minCount, maxCount)
    if type(foe) ~= "table" or type(foe.party) ~= "table" then return foe end
    minCount = math.max(1, math.min(6, tonumber(minCount) or 1))
    maxCount = math.max(minCount, math.min(6, tonumber(maxCount) or minCount))
    local targetCount = minCount
    if maxCount > minCount then
      local state = hashString("two-opponent-count|" .. tostring(trainerId) .. "|" .. tostring(minCount) .. "|" .. tostring(maxCount), activeSeed())
      targetCount = minCount + (state % (maxCount - minCount + 1))
    end
    if #foe.party >= targetCount then
      if #foe.party > maxCount then
        while #foe.party > maxCount do table.remove(foe.party) end
      end
      return foe
    end

    local used = {}
    for _, row in ipairs(foe.party) do
      local internal = row and tonumber(row.species)
      if internal then used[speciesIdentity(internal)] = true end
    end
    local info = nil
    local reg = mod.content and mod.content.trainers
    if reg and type(reg.get) == "function" then
      local ok, row = pcall(function() return reg:get(trainerId) end)
      if ok and type(row) == "table" then info = row end
    end
    local template = foe.party[#foe.party] or (info and info.party and info.party[#info.party]) or {}
    local baseLevel = tonumber(template.level) or tonumber(info and info.lastLevel) or 5
    while #foe.party < targetCount and #foe.party < maxCount do
      local slot = #foe.party + 1
      local target = randomTrainerSpecies(trainerId, slot, nil, used)
      if not target then break end
      used[speciesIdentity(target)] = true
      local row = cloneTable(template)
      row.species = target
      row.level = tonumber(row.level) or baseLevel
      row.moves = nil
      foe.party[#foe.party + 1] = row
    end
    return foe
  end


  -- Dynamic level cap: cap is derived from the effective randomized party of
  -- the next gym leader / champion. At/above cap, the recipient gets exactly
  -- 1 EXP per defeated foe. Levels are never reduced retroactively.
  local levelCapState = { partyByTrainer = {}, leaderByGame = {}, championByGame = {}, warned = false }
  local function capName(s)
    return tostring(s or ""):upper():gsub("[^A-Z0-9]", "")
  end
  local function activeGameKey()
    local ok, Constants = pcall(require, "src.core.game3.constants")
    if not ok or not Constants then return nil end
    local session
    local okR, Runtime = pcall(require, "src.core.game3.runtime")
    if okR and Runtime and type(Runtime.getSession) == "function" then
      local okS, v = pcall(Runtime.getSession); if okS then session = v end
    end
    local okK, game = pcall(Constants.versionOf, session)
    if not okK then return nil end
    if game == "sapphire" then return "ruby" end
    if game == "leafgreen" then return "firered" end
    return game
  end
  local function activeStore()
    local ok, Space = pcall(require, "src.core.game3.scripting.space")
    if ok and Space and type(Space.getStore) == "function" then
      local okS, store = pcall(Space.getStore)
      if okS and type(store) == "table" then return store end
    end
    return nil
  end
  local function flagValue(name)
    local store = activeStore()
    if not store then return false end
    local ok, Flags = pcall(require, "src.core.game3.scripting.flags")
    if not ok or not Flags or type(Flags.getFlag) ~= "function" then return false end
    local game = activeGameKey()
    local okC, Constants = pcall(require, "src.core.game3.constants")
    if not okC or not Constants then return false end
    local okT, c = pcall(Constants.of, game)
    if not okT or not c or not c.flags or not c.flags.byName then return false end
    local id = c.flags.byName[name]
    if id == nil then return false end
    local okF, value = pcall(Flags.getFlag, store, nil, id)
    return okF and value == true
  end
  local function badgeCount()
    local store = activeStore()
    if not store then return nil end
    local ok, Flags = pcall(require, "src.core.game3.scripting.flags")
    if not ok or not Flags or type(Flags.countBadges) ~= "function" then return nil end
    local okN, n = pcall(Flags.countBadges, store)
    return okN and tonumber(n) or nil
  end
  local function trainerRowLabel(row, id)
    return capName(tostring(id or "") .. " " .. tostring(row and row.name or "") .. " " .. tostring(row and row.className or ""))
  end
  local function findTrainerForName(name, champion)
    local reg = mod.content and mod.content.trainers
    if not reg or type(reg.each) ~= "function" or type(reg.get) ~= "function" then return nil end
    local ids = reg:each()
    if type(ids) == "function" then local list = {}; for id in ids do list[#list+1]=id end; ids=list end
    if type(ids) ~= "table" then return nil end
    local want = capName(name)
    local bestId, bestScore
    for _, id in ipairs(ids) do
      local ok, row = pcall(function() return reg:get(id) end)
      if ok and type(row) == "table" and type(row.party) == "table" and #row.party > 0 then
        local label = trainerRowLabel(row, id)
        if label:find(want, 1, true) then
          -- Prefer the base encounter over rematches (IDs with _2.._5,
          -- REVENGE, rematch labels, etc.). The party cache is refreshed
          -- after randomizeTrainers patches the registry.
          local idText = tostring(id):upper()
          local score = 100
          if idText:match("_%d+$") then
            local suffix = tonumber(idText:match("_(%d+)$")) or 1
            score = score - suffix * 10
          end
          if idText:find("REMATCH",1,true) or idText:find("REVENGE",1,true) then score = score - 80 end
          if row.rematch then score = score - 80 end
          if not bestScore or score > bestScore then bestId, bestScore = id, score end
        end
      end
    end
    return bestId
  end
  local function refreshCapTrainerCache()
    levelCapState.partyByTrainer = {}
    local reg = mod.content and mod.content.trainers
    if not reg or type(reg.each) ~= "function" or type(reg.get) ~= "function" then return end
    local ids = reg:each()
    if type(ids) == "function" then local list = {}; for id in ids do list[#list+1]=id end; ids=list end
    if type(ids) ~= "table" then return end
    for _, id in ipairs(ids) do
      local ok, row = pcall(function() return reg:get(id) end)
      if ok and type(row) == "table" and type(row.party) == "table" and #row.party > 0 then
        local maxLevel = 0
        for _, slot in ipairs(row.party) do maxLevel = math.max(maxLevel, tonumber(slot.level) or 0) end
        if maxLevel > 0 then levelCapState.partyByTrainer[id] = maxLevel end
      end
    end
  end

  local function gameProgressNames(game)
    if game == "emerald" then
      return {"ROXANNE", "BRAWLY", "WATTSON", "FLANNERY", "NORMAN", "WINONA", "TATE", "JUAN"}, {"WALLACE"}
    elseif game == "ruby" then
      return {"ROXANNE", "BRAWLY", "WATTSON", "FLANNERY", "NORMAN", "WINONA", "TATE", "WALLACE"}, {"STEVEN"}
    elseif game == "firered" then
      return {"BROCK", "MISTY", "LT SURGE", "ERIKA", "KOGA", "SABRINA", "BLAINE", "GIOVANNI"}, {"CHAMPION", "RIVAL"}
    end
    return nil, nil
  end
  local function effectivePartyMaxForNames(names)
    local best
    local reg = mod.content and mod.content.trainers
    for _, name in ipairs(names or {}) do
      local id = findTrainerForName(name, false)
      local maxLevel = id and levelCapState.partyByTrainer[id]
      if not maxLevel and id and reg and type(reg.get) == "function" then
        local ok, row = pcall(function() return reg:get(id) end)
        if ok and type(row) == "table" then
          maxLevel = 0
          for _, slot in ipairs(row.party or {}) do maxLevel = math.max(maxLevel, tonumber(slot.level) or 0) end
        end
      end
      if maxLevel and maxLevel > 0 and (not best or maxLevel > best) then best = maxLevel end
    end
    return best
  end
  local function currentLevelCap()
    if mod.options:get("level_cap_enabled") == false then return nil end
    local game = activeGameKey()
    local leaders, championNames = gameProgressNames(game)
    if not leaders then return nil end
    if flagValue("FLAG_SYS_GAME_CLEAR") then return 100 end
    local badges = badgeCount()
    if badges == nil then return nil end
    if badges >= 8 then return effectivePartyMaxForNames(championNames) end
    return effectivePartyMaxForNames({leaders[math.max(1, math.min(8, badges + 1))]})
  end
  local function installLevelCapHook()
    if mod.__crazyLevelCapHook0416 then return end
    mod.hooks:wrap("exp.gain", function(nextGain, ctx)
      local amount = nextGain()
      if mod.options:get("level_cap_enabled") == false or type(ctx) ~= "table" or type(ctx.mon) ~= "table" then
        return amount
      end
      local cap = currentLevelCap()
      local level = tonumber(ctx.mon.level) or 1
      if cap and level >= cap then return 1 end
      return amount
    end)
    mod.__crazyLevelCapHook0416 = true
    mod.log:info("Crazy Level Cap v0.4.17 installed (dynamic leader/champion cap; 1 EXP at/above cap)")
  end

  -- Keep immutable vanilla trainer rows. The content registry is patched in-place;
  -- without this snapshot, a new seed can accidentally randomize a previously
  -- randomized party instead of starting from the game's original trainer data.
  local trainerOriginalRows = {}
  local function getOriginalTrainerRow(reg, trainerId)
    local cached = trainerOriginalRows[trainerId]
    if cached then return cloneTable(cached) end
    local ok, row = pcall(function() return reg:get(trainerId) end)
    if not ok or type(row) ~= "table" then return nil end
    local snapshot = cloneTable(row)
    trainerOriginalRows[trainerId] = snapshot
    return cloneTable(snapshot)
  end

  local function captureOriginalTrainerRows(reg)
    if not reg or type(reg.each) ~= "function" or type(reg.get) ~= "function" then return end
    local ids = reg:each()
    if type(ids) == "function" then local list = {}; for id in ids do list[#list + 1] = id end; ids = list end
    if type(ids) ~= "table" then return end
    for _, trainerId in ipairs(ids) do
      if not trainerOriginalRows[trainerId] then
        local ok, row = pcall(function() return reg:get(trainerId) end)
        if ok and type(row) == "table" then trainerOriginalRows[trainerId] = cloneTable(row) end
      end
    end
  end

  local function randomizeTrainers()
    if mod.options:get("randomize_trainers") == false then return end
    local reg = mod.content and mod.content.trainers
    if not reg or type(reg.each) ~= "function" or type(reg.get) ~= "function" then
      mod.log:warn("Trainer registry unavailable; trainer randomization skipped")
      return
    end
    local ids = reg:each()
    if type(ids) == "function" then local list = {}; for id in ids do list[#list + 1] = id end; ids = list end
    if type(ids) ~= "table" then return end
    captureOriginalTrainerRows(reg)
    local changed, rebuilt = 0, 0
    for _, trainerId in ipairs(ids) do
      local original = getOriginalTrainerRow(reg, trainerId)
      if type(original) == "table" and type(original.party) == "table" and #original.party > 0 then
        local party, theme, role = rebuildTrainerParty(original, trainerId)
        if #party > 0 then
          local patch = { party = party, partySize = #party }
          pcall(function() reg:patch(trainerId, patch) end)
          changed = changed + #party
          rebuilt = rebuilt + 1
          if theme then mod.log:info("Crazy trainer %s %s: 6-mon %s theme", tostring(trainerId), tostring(role), theme) end
        end
      end
    end
    refreshCapTrainerCache()
    mod.log:info("Crazy trainer randomizer: seed=%d; rebuilt %d trainers / %d party slots; no duplicate species per party; Megas=%s", activeSeed(), rebuilt, changed, tostring(mod.options:get("trainer_allow_megas") == true))
  end

  local function resetSeedDependentRuntimeState()
    poolCache, learnsetCache, moveCache, trainerCache = {}, {}, {}, {}
    trainerPoolCache, speciesIdentityCache = {}, {}
    speciesCatalog = nil
    encounterStates = {}
  end

  mod.events:on("save.created", function()
    persistFreshPlaythroughSeed(true)
    resetSeedDependentRuntimeState()
    if mod.options:get("randomize_moves") ~= false then applyRandomMoves() end
    randomizeTrainers()
  end)

  -- Loading a save restores its own seed. Rebuild seed-dependent runtime data
  -- from the immutable vanilla trainer snapshots so the previous active save's
  -- patched trainer teams cannot leak into the loaded playthrough.
  mod.events:on("save.loaded", function()
    persistFreshPlaythroughSeed(false)
    resetSeedDependentRuntimeState()
    if mod.options:get("randomize_moves") ~= false then applyRandomMoves() end
    randomizeTrainers()
  end)

  mod.events:on("mod.options_changed", function(ev)
    if type(ev) ~= "table" or ev.mod ~= mod.id then return end
    if ev.key == "reroll_seed" and ev.value == "generate" then
      mod.log:info("Crazy Randomizer: Generate new random seed action received")
      local seed = rerollSeed()
      saveSeed(seed)
      resetSeedDependentRuntimeState()
      if mod.options:get("randomize_moves") ~= false then applyRandomMoves() end
      randomizeTrainers()
      mod.log:info("Crazy Randomizer: generated new seed %d; activeSeed()=%d", seed, activeSeed())
    elseif ev.key == "randomize_moves" or ev.key == "type_affinity" or ev.key == "randomize_trainers" or ev.key == "trainer_allow_megas" or ev.key == "trainer_party_mode" then
      poolCache, learnsetCache, moveCache, trainerCache = {}, {}, {}, {}
      trainerPoolCache, speciesIdentityCache = {}, {}
      if mod.options:get("randomize_moves") ~= false then applyRandomMoves() end
      randomizeTrainers()
    end
  end)

  -- Emerald/Gen3 can leave trainer intros waiting when native enemy
  -- MonAnim start/wait paths are reached for randomized/extended species.
  -- Filter the intro/switch steps and add a hard guard around direct start/busy
  -- calls. Player back animations and wild encounters remain untouched.
  local function installExtendedTrainerAnimationSafety()
    local okM, MonAnimBattle = pcall(require, "src.core.game3.battle.mon_anim_battle")
    local okB, Battle = pcall(require, "src.core.game3.battle")
    if mod.options:get("trainer_extended_anim_safety") == false then return end
    if not okM or type(MonAnimBattle) ~= "table" or type(MonAnimBattle.introSteps) ~= "function"
        or not okB or type(Battle) ~= "table" then
      mod.log:warn("Crazy trainer animation safety: MonAnimBattle/Battle unavailable")
      return
    end
    if MonAnimBattle.__crazyHardTrainerEnemyAnimSafety0410 then return end

    local function speciesOfBattler(b)
      if type(b) ~= "table" then return nil end
      return tonumber(b.species or (b.mon and (b.mon.species or b.mon.speciesId)))
    end

    local function extendedSpecies(sp)
      sp = tonumber(sp)
      if not sp then return false end
      local okN, national = pcall(Pokemon.national, sp)
      return okN and tonumber(national) ~= nil and tonumber(national) > 386
    end

    local function enemyTrainerKey(st, key)
      if type(st) ~= "table" or st.wild or st.link or st.trainerId == nil then return false end
      if key == "enemy" then return true end
      if type(key) == "number" then
        -- Gen3 battle ids alternate player/enemy in doubles: 0/2 player, 1/3 enemy.
        return (key % 2) == 1
      end
      return false
    end

    local function enemyKeyIsExtended(st, key)
      if not enemyTrainerKey(st, key) then return false end
      if key == "enemy" then return extendedSpecies(speciesOfBattler(st.enemy)) end
      local b = st.battlers and st.battlers[key]
      if not b then
        local okS, State = pcall(require, "src.core.game3.battle.state")
        if okS and State and type(State.battler) == "function" then
          local okB2, bb = pcall(State.battler, st, key)
          if okB2 then b = bb end
        end
      end
      return extendedSpecies(speciesOfBattler(b))
    end

    local function filterEnemyExtendedSteps(steps)
      local st = Battle._st
      if type(st) ~= "table" or st.wild or st.link or st.trainerId == nil then return steps end
      local out = {}
      for _, step in ipairs(steps or {}) do
        local kind = step and step.kind
        local d = step and step.data or {}
        if kind == "mon_anim" or kind == "mon_anim_wait" then
          local ids = d.ids or { d.id ~= nil and d.id or d.side or "enemy" }
          local skip = false
          local reason = nil
          if mod.options:get("trainer_skip_enemy_anim") ~= false then
            for _, key in ipairs(ids) do
              if enemyTrainerKey(st, key) then
                skip = true
                reason = enemyKeyIsExtended(st, key) and "trainer enemy animation safety (extended)" or "trainer enemy animation safety (all trainer foes)"
                break
              end
            end
          end
          if skip then
            mod.log:info("Crazy trainer animation safety: skipped native %s (%s)", tostring(kind), tostring(reason))
          else
            out[#out + 1] = step
          end
        else
          out[#out + 1] = step
        end
      end
      return out
    end

    local originalIntroSteps = MonAnimBattle.introSteps
    MonAnimBattle.introSteps = function(steps, wild)
      return filterEnemyExtendedSteps(originalIntroSteps(steps, wild))
    end

    if type(MonAnimBattle.switchSteps) == "function" then
      local originalSwitchSteps = MonAnimBattle.switchSteps
      MonAnimBattle.switchSteps = function(steps)
        return filterEnemyExtendedSteps(originalSwitchSteps(steps))
      end
    end

    -- Hard safety layer for Emerald: some trainer paths can still call
    -- MonAnimBattle.start/busy after the step list has been built.  Do not
    -- start or wait on native enemy mon animations for ANY trainer battle.
    -- Player back animations remain untouched; wild battles remain untouched.
    local originalStart = MonAnimBattle.start
    MonAnimBattle.start = function(key, kind, opts)
      local st = (opts and opts.st) or Battle._st
      if enemyTrainerKey(st, key) and mod.options:get("trainer_skip_enemy_anim") ~= false then
        return nil
      end
      return originalStart(key, kind, opts)
    end

    local originalBusy = MonAnimBattle.busy
    MonAnimBattle.busy = function(keys)
      local st = Battle._st
      if type(st) == "table" and not st.wild and not st.link and st.trainerId ~= nil
          and mod.options:get("trainer_skip_enemy_anim") ~= false then
        local playerKeys = {}
        for _, key in ipairs(keys or {}) do
          if not enemyTrainerKey(st, key) then playerKeys[#playerKeys + 1] = key end
        end
        if #playerKeys == 0 then return false end
        return originalBusy(playerKeys)
      end
      return originalBusy(keys)
    end

    MonAnimBattle.__crazyExtendedTrainerAnimSafety045 = true
    MonAnimBattle.__crazyHardTrainerEnemyAnimSafety0410 = true
    mod.log:info("Crazy trainer animation safety v0.4.10 installed: native enemy MonAnim start/wait bypassed for ALL trainer battles; player/wild animation remains active")
  end

  installExtendedTrainerAnimationSafety()

  -- The Gen 3 battle bridge reads its live trainer party from the engine's
  -- battle data, which is not guaranteed to be the same registry object exposed
  -- by mod.content.trainers. Randomize the party at the actual battle boundary
  -- so the active playthrough seed controls the team Brock and every other
  -- trainer really use, rather than relying only on a global registry patch.
  local function installTrainerSpeciesHook()
    if mod.__crazyTrainerSpeciesHook0424 then return end
    mod.hooks:wrap("trainer.party", function(nextParty, oppClass, trainerId, party)
      local out = nextParty(oppClass, trainerId, party) or party
      if mod.options:get("randomize_trainers") == false or type(out) ~= "table" or #out == 0 then
        return out
      end
      local reg = mod.content and mod.content.trainers
      local original = nil
      if reg and type(reg.get) == "function" and trainerId ~= nil then
        -- Crucial: do not classify the trainer using a row already patched by
        -- a previous randomization. The vanilla row preserves the original
        -- party count used to identify the first rival battle and the role.
        original = getOriginalTrainerRow(reg, trainerId)
      end
      if type(original) ~= "table" then original = {} end
      original.party = type(original.party) == "table" and original.party or cloneTable(out)
      original.name = original.name or tostring(trainerId or "")
      original.className = original.className or tostring(oppClass or "")
      local rebuilt = rebuildTrainerParty(original, trainerId or (tostring(oppClass) .. "|" .. tostring(trainerId)))
      if type(rebuilt) ~= "table" or #rebuilt == 0 then return out end
      mod.log:info("Crazy trainer battle hook: trainer=%s class=%s seed=%d slots=%d->%d",
        tostring(trainerId), tostring(oppClass), activeSeed(), #out, #rebuilt)
      return rebuilt
    end, -10)
    mod.__crazyTrainerSpeciesHook0424 = true
    mod.log:info("Crazy trainer species hook installed: teams rebuilt at trainer.party using active per-playthrough seed")
  end
  installTrainerSpeciesHook()

  -- Keep the trainer-intro Poké Ball count aligned with the randomized party.
  -- Gen3's intro sequence reads Trainers.info(...).partySize separately from
  -- the party returned by trainer.party, so patch the presentation count from
  -- the same live trainer registry when available.
  local function installTrainerBallCountSync()
    if mod.__crazyTrainerBallCountSync0425 then return end
    local ok, Trainers = pcall(require, "src.core.game3.scripting.trainers")
    if not ok or type(Trainers) ~= "table" or type(Trainers.info) ~= "function" then
      mod.log:warn("Crazy trainer Poké Ball count sync: Trainers.info unavailable")
      return
    end
    local previousInfo = Trainers.info
    Trainers.info = function(trainerId, opts)
      local info = previousInfo(trainerId, opts)
      if type(info) ~= "table" then return info end
      local reg = mod.content and mod.content.trainers
      if reg and type(reg.get) == "function" and trainerId ~= nil then
        local okRow, row = pcall(function() return reg:get(tonumber(trainerId) or trainerId) end)
        if okRow and type(row) == "table" then
          local n = type(row.party) == "table" and #row.party or tonumber(row.partySize)
          if n and n > 0 then info.partySize = math.max(1, math.min(6, n)) end
        end
      end
      return info
    end
    mod.__crazyTrainerBallCountSync0425 = true
    mod.log:info("Crazy trainer Poké Ball count sync v0.4.25 installed")
  end
  installTrainerBallCountSync()

  -- Current Gen1Recomp's battle builder honors a slot-local moves list from
  -- the trainer.party hook.  The registry schema intentionally remains
  -- {level, species}, so do not patch `moves` into the content registry.
  local function installTrainerMoveHook()
    if mod.options:get("randomize_moves") == false then return end
    if mod.__crazyTrainerMoveHook048 then return end
    mod.hooks:wrap("trainer.party", function(nextParty, oppClass, partyIndex, party)
      local out = nextParty(oppClass, partyIndex, party) or party
      if type(out) ~= "table" then return out end
      local copy = {}
      for i, slot in ipairs(out) do
        local row = cloneTable(slot)
        local target = row and row.species and Pokemon.speciesFromName(row.species)
        if target then
          local level = tonumber(row.level) or 1
          local moves = trainerMovesAtLevel(target, level)
          if type(moves) ~= "table" or #moves < 4 then
            moves = buildRandomMoveIds(target, 4)
          end
          local names = moveNamesForIds(moves)
          if #names >= 4 then
            row.moves = { names[1], names[2], names[3], names[4] }
          else
            -- Never deliberately leave a randomized trainer with an empty
            -- move list: use four distinct executable IDs and resolve them.
            local fallback = buildRandomMoveIds(target, 4)
            local fn = moveNamesForIds(fallback)
            if #fn >= 4 then row.moves = { fn[1], fn[2], fn[3], fn[4] } end
          end
        end
        copy[i] = row
      end
      return copy
    end)
    mod.__crazyTrainerMoveHook048 = true
    mod.log:info("Crazy trainer move hook installed: four distinct executable randomized moves per trainer slot; STRUGGLE excluded")
  end
  installTrainerMoveHook()

  local okBridge, Bridge = pcall(require, "src.core.game3.battle_bridge")
  if okBridge and type(Bridge) == "table" and type(Bridge.twoOpponentFoe) == "function"
      and not Bridge.__crazyOptionalMandatoryDouble049 then
    local originalTwoOpponentFoe = Bridge.twoOpponentFoe
    Bridge.twoOpponentFoe = function(foeA, trainerIdB)
      local trainerIdA = foeA and foeA.trainerId
      -- Facility teams must retain their original sizes even in a doubles
      -- battle; leave this battle builder's party assembly untouched for them.
      if isBattleFrontierTrainer(nil, trainerIdA) or isBattleFrontierTrainer(nil, trainerIdB) then
        return originalTwoOpponentFoe(foeA, trainerIdB)
      end
      local mandatory = twoOpponentMandatoryPair(trainerIdA, trainerIdB)
      local minCount, maxCount
      if mandatory then
        -- Inseparable/mandatory pairs: 2-6 per trainer.  Important/gym
        -- trainers are already six in the randomized registry.
        minCount, maxCount = 2, 6
      else
        -- Optional simultaneous sight-line doubles: exactly 2-3 per trainer.
        minCount = 2
        maxCount = tonumber(mod.options:get("trainer_optional_double_cap")) or 3
        maxCount = math.max(2, math.min(3, maxCount))
      end

      local a = ensureTrainerPartyRows(foeA, trainerIdA, minCount, maxCount)
      local okT, Trainers = pcall(require, "src.core.game3.scripting.trainers")
      local b = okT and Trainers.foeFromId(trainerIdB) or nil
      if not b then return originalTwoOpponentFoe(a, trainerIdB) end
      b = ensureTrainerPartyRows(b, trainerIdB, minCount, maxCount)

      local out = {}
      for k, v in pairs(a) do out[k] = v end
      local party = {}
      for i = 1, math.min(maxCount, #a.party) do party[#party + 1] = a.party[i] end
      local half = #party
      for i = 1, math.min(maxCount, #b.party) do party[#party + 1] = b.party[i] end
      out.party = party
      mod.log:info("Crazy double rule: %s pair %s/%s => %d + %d", mandatory and "MANDATORY" or "OPTIONAL", tostring(trainerIdA), tostring(trainerIdB), math.min(maxCount, #a.party), math.min(maxCount, #b.party))
      return out, half
    end
    Bridge.__crazyOptionalMandatoryDouble049 = true
    mod.log:info("Crazy v0.4.9: optional doubles are 2-3 each; mandatory/inseparable pairs are 2-6 each; important/gym leaders stay at 6")
  end
  if not okBridge or type(Bridge) ~= "table" or type(Bridge.startWild) ~= "function" then
    mod.log:error("Gen3 BattleBridge.startWild is unavailable; Crazy Randomizer cannot start")
    return
  end
  if Bridge[MOD_TAG] then return end

  local function installUntamedExactBridgeMarker()
    if not (mod.options:get("untamed_compat") and untamed) then return end
    local peer = mod:find("untamed_advanced")
    local engine = peer and peer.exports and peer.exports.engine
    if type(engine) ~= "table" or type(engine.startWildBattle) ~= "function" or engine.__crazyRandomizerExact042 then return end
    local originalUntamedStart = engine.startWildBattle
    engine.startWildBattle = function(foe, roamer, done)
      if not roamer and type(foe) == "table" then
        local copy = cloneTable(foe); copy.__crazyUntamedExact = true; foe = copy
      end
      return originalUntamedStart(foe, roamer, done)
    end
    engine.__crazyRandomizerExact042 = true
  end
  mod.events:once("mods.loaded", installUntamedExactBridgeMarker)

  local originalStartWild = Bridge.startWild
  Bridge.startWild = function(owner, game, encounter, opts)
    opts = opts or {}
    local standardWild = opts.wild ~= false and not opts.trainerId and not opts.wildScripted
      and not opts.legendary and not opts.roamer and not opts.firstBattle
      and not opts.oldManTutorial and type(encounter) == "table"
      and not encounter.roamer and not encounter.wildScripted
      and not encounter.legendary and not encounter.specialWild

    if standardWild and encounter.__crazyUntamedExact then
      opts = cloneTable(opts); opts.__completeDexExact = true; opts[MOD_TAG] = true
      encounter = cloneTable(encounter); encounter.__crazyUntamedExact = nil
    elseif standardWild and not opts.__completeDexExact and not encounter.__crazyRandomized then
      local rewritten = rewriteEncounter(encounter, game, opts)
      if rewritten ~= encounter then
        opts = cloneTable(opts); opts.__completeDexExact = true; opts[MOD_TAG] = true
        encounter = rewritten
      end
    end
    return originalStartWild(owner, game, encounter, opts)
  end

  -- Rewrite script gifts (including eggs/fossils/NPC gifts that use the common
  -- give-Pokemon path) using the same per-save species pool.
  local function randomInternalForKey(key)
    local rows = catalog().nationals
    if type(rows) ~= "table" or #rows == 0 then return nil end
    local candidates = {}
    for _, national in ipairs(rows) do
      local internal = internalFromNational(national)
      if internal then candidates[#candidates + 1] = { national = national, internal = internal } end
    end
    if #candidates == 0 then return nil end
    local state = hashString(tostring(key or "gift"), activeSeed())
    local idx = (nextRand({ value = state }) % #candidates) + 1
    return candidates[idx].internal, candidates[idx].national
  end

  if mod.events and mod.events.on then
    mod.events:on("pokemon.before_give", function(ev)
      if type(ev) ~= "table" or ev.__crazyRandomizedGift then return end
      local original = tonumber(ev.speciesId) or tonumber(ev.species)
      local replacement = randomInternalForKey("gift|" .. tostring(original or ev.species or "unknown"))
      if replacement then ev.species = replacement; ev.speciesId = replacement; ev.__crazyRandomizedGift = true end
    end)
  end

  -- RSE starters are created by a native helper rather than script give_mon.
  -- Preserve the selected starter slot for rival counter-picks, but replace the
  -- species actually placed in the party.
  do
    local ok, FieldRse = pcall(require, "src.core.game3.scripting.natives_field_rse")
    if ok and type(FieldRse) == "table" and type(FieldRse.giveStarter) == "function"
        and not FieldRse.__crazyRandomizerStarterHook0421 then
      local originalGiveStarter = FieldRse.giveStarter
      FieldRse.giveStarter = function(ctx, selection, sess)
        local replacement = randomInternalForKey("starter|" .. tostring(selection))
        if not replacement then return originalGiveStarter(ctx, selection, sess) end
        local Rse = require("src.core.game3.rse.init")
        sess = sess or Rse.session()
        local Party = require("src.core.game3.party")
        Rse.setVar("VAR_STARTER_MON", selection, sess)
        return replacement, Party.giveMonToPlayer(sess, replacement, 5)
      end
      FieldRse.__crazyRandomizerStarterHook0421 = true
    end
  end

  -- Eggs and NPC trades bypass the ordinary script gift event in several
  -- Gen3 paths, so wrap their common creation functions as well.
  do
    local ok, Party = pcall(require, "src.core.game3.party")
    if ok and type(Party) == "table" and type(Party.giveEggToPlayer) == "function"
        and not Party.__crazyRandomizerEggHook0421 then
      local originalGiveEgg = Party.giveEggToPlayer
      Party.giveEggToPlayer = function(session, species, ...)
        local replacement = randomInternalForKey("egg|" .. tostring(species or "unknown"))
        return originalGiveEgg(session, replacement or species, ...)
      end
      Party.__crazyRandomizerEggHook0421 = true
    end
  end

  do
    local ok, Trade = pcall(require, "src.core.game3.scripting.natives_trade")
    if ok and type(Trade) == "table" and type(Trade.createTradeMon) == "function"
        and not Trade.__crazyRandomizerTradeHook0421 then
      local originalCreateTradeMon = Trade.createTradeMon
      Trade.createTradeMon = function(tradeIdx, level, opts)
        local mon = originalCreateTradeMon(tradeIdx, level, opts)
        if mon then
          local replacement = randomInternalForKey("trade|" .. tostring(tradeIdx))
          if replacement then
            mon.species, mon.speciesId = replacement, replacement
            mon.nickname, mon.name = nil, nil
            pcall(function() Pokemon.applyStats(mon) end)
          end
        end
        return mon
      end
      Trade.__crazyRandomizerTradeHook0421 = true
    end
  end

  -- Teachy TV's demo battles use a separate hard-coded party builder. Rewrite
  -- those generated demo mons without changing the engine's demo flow.
  do
    local ok, Pokedude = pcall(require, "src.core.game3.battle.pokedude")
    if ok and type(Pokedude) == "table" and type(Pokedude.build) == "function"
        and not Pokedude.__crazyRandomizerTeachyHook0421 then
      local originalBuild = Pokedude.build
      Pokedude.build = function(scriptId)
        local party, foes = originalBuild(scriptId)
        local function rewrite(list, side)
          for i, mon in ipairs(list or {}) do
            local replacement = randomInternalForKey("teachy|" .. tostring(scriptId) .. "|" .. side .. "|" .. tostring(i))
            if replacement and mon then
              mon.species = replacement
              pcall(function() Pokemon.applyStats(mon) end)
              pcall(function() mon.moves = randomizedMovesFor(replacement) end)
            end
          end
        end
        rewrite(party, "player"); rewrite(foes, "opponent")
        return party, foes
      end
      Pokedude.__crazyRandomizerTeachyHook0421 = true
    end
  end

  Bridge[MOD_TAG] = true
  installRandomMoveHooks()
  randomizeTrainers()
  installLevelCapHook()
  mod.log:info("Crazy Randomizer v%s ready: runtime forms=%d, Megas=%s, Gigantamax excluded; leader themes active; extended trainer animation safety active; WildFollowers API bridge active; optional/mandatory double rules active", MOD_VERSION, #formIds, tostring(mod.options:get("trainer_allow_megas") == true))
end
