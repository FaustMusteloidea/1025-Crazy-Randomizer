# 1025Dex Crazy Randomizer v0.4.25 (Experimental)

**Created and maintained by Faust, with development assistance from ChatGPT (OpenAI).**

1025Dex Crazy Randomizer is an independent gameplay mod for Gen1Recomp's Generation III Pokémon games. It expands species variety in wild encounters and trainer battles, and adds runtime support for alternate forms. This package is experimental; see the known issues below before using it.

## Compatibility and installation

- Requires the official **1025Dex v1.2.16 or newer compatible release** installed separately.
- **Untamed Advanced is optional**, not a required dependency. If installed and the compatibility path is enabled, Crazy can synchronize randomized overworld encounters with its selected species table.
- Declared game targets: **Pokémon Emerald, Ruby, Sapphire, FireRed, and LeafGreen**. Feature coverage may differ by game; not every behavior has been verified in every target.
- Install this ZIP as a Gen1Recomp mod package using the mod manager. Do not install multiple copies of Crazy Randomizer at once. Back up saves before testing.
- This mod does not include or replace the official 1025Dex mod.

## Feature overview

The following describes the current code/history as understood at v0.4.25. Some paths remain experimental or need in-game verification; see **Known issues and limitations**.

- Wild encounter randomization and expanded species pools, including support work for National Dex species and alternate forms provided by the 1025Dex ecosystem.
- Shared encounter-table compatibility work for classic wild encounters, DexNav, WildFollowers and optional Untamed Advanced integration.
- Trainer species and move randomization, with role-based party-size rules and runtime rebuilding from the vanilla trainer baseline.
- Trainer modes discussed/implemented across the project: **Vanilla**, **Medium** (intended default), and **Full Pokémon**. Exact party-size and special-trainer exceptions are still being stabilized.
- Gym-leader type themes and no-duplicate species logic in trainer parties; Mega forms are permitted by default in the trainer pool while Gigantamax is excluded.
- Randomized trainer move sets use executable Generation III move IDs; STRUGGLE is excluded from deliberate move selection. Alternate forms without a learnset can inherit progression from their base species.
- Runtime alternate-form catalogue and support for extended species/form data without bundling or modifying the official 1025Dex installation.
- Optional Untamed Advanced compatibility rather than a hard dependency.
- Per-playthrough seed and seed-regeneration work, including rebuilding trainer parties from an immutable snapshot of vanilla trainer rows.
- Trainer intro Poké Ball-count synchronization work in v0.4.25.

## Known issues and limitations

- **Battle Frontier (Emerald): critical known issue.** The user has reported that Battle Frontier battles freeze. Avoid Battle Frontier battles until this is fixed and verified.
- **Seed isolation is not confirmed fixed.** Earlier tests reported repeated trainer teams across fresh starts and the “Generate new random seed” menu action appearing ineffective. v0.4.23–v0.4.25 contain code intended to address this, but these builds have not been validated in-game by the developer.
- Trainer party-size display and actual party-size mismatches have been reported in FireRed/LeafGreen and Emerald. v0.4.25 adds Poké Ball-count synchronization and stricter role classification, but needs testing.
- Gym-helper-to-leader type inheritance is not implemented in v0.4.25; this build constrains the leader's own type pool only.
- First-rival party-size exceptions and important-trainer classification have been revised, but require verification across all supported games.
- Ruby/Sapphire starter and scripted-event randomization coverage is not fully verified.
- Some scripted/tutorial/acquisition encounters have been reported as not yet randomized consistently, including the Old Man Weedle encounter in FireRed/LeafGreen, Wally's tutorial Zigzagoon, and Birch's chase encounter in Hoenn. Teachy TV was handled through a separate scripted hook and should not be assumed to cover these other paths.
- Untamed Advanced's own visible-sprite/battle-species edge cases may depend on upstream behavior; optional compatibility does not guarantee every external-mod bug is solved.
- This package has been structurally inspected, but **v0.4.25 has not been confirmed through comprehensive in-game testing**. Do not treat it as a stable release.

## Roadmap (not claimed as implemented)

1. Confirm per-save/per-playthrough seed independence and make “Generate new random seed” reliably rebuild the active save's trainer teams.
2. Reconcile trainer party size, intro Poké Ball counts, first-rival exceptions, leader themes, gym-trainer themes, and double-battle rules across Emerald, Ruby, Sapphire, FireRed, and LeafGreen.
3. Fix the Emerald Battle Frontier freeze while preserving original party sizes there.
4. Complete scripted encounters: Old Man Weedle, Wally tutorial Zigzagoon, Birch chase encounters, and other gift/NPC/event/static/tutorial paths.
5. Implement HM use without requiring the player to teach the move, while preserving badge/story requirements.
6. Continue work on menu options, seed controls, and optional Hoenn contest-area teleport functionality.
7. Continue compatibility tests with 1025Dex, DexNav, WildFollowers, and optional Untamed Advanced; remove development diagnostics from release builds when no longer needed.
8. Test ecological/chaotic encounter options, time-based tables, surf/fishing, weather, and special encounter methods across all declared games before calling the package stable.

## Credits and project status

- **Author / project creator:** Faust.
- **Development assistance:** ChatGPT by OpenAI (planning, implementation assistance, debugging, documentation and changelog reconstruction).
- **Dependencies / integrations:** Gen1Recomp, official 1025Dex, and optional community mods such as Untamed Advanced, DexNav and WildFollowers where installed.

This is an independent community mod, not an official Pokémon, Nintendo, Game Freak, Gen1Recomp, or 1025Dex release. Pokémon and related names are the property of their respective owners. Respect the licenses and notices of Gen1Recomp and all third-party dependencies.
